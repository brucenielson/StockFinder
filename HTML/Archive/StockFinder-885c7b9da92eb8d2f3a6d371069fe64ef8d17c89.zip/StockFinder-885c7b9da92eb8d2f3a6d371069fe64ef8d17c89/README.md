StockFinder
===========

A program in Python to help me find the best dividend stocks that match my criteria.
The program uses a dividend strategy and comes up with a "fair price" for each stock,
then compares it to the actual price and recommends stocks that are currently worth buying.
