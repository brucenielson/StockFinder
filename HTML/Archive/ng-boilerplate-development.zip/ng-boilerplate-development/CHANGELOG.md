# Changes to ng-boilerplate

## v1.2.0

1. Added #21: Add stylish reporter for jshint and make modifications to .jshintrc file
2. Added #20: Add CHANGELOG.md
3. Added #19: Add command line arguments to gulp commands to allow testing options
