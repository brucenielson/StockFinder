define(
  [
    'angular-mocks',
    'js/app',
    'js/service/name-service'
  ],
  function() {
    describe('NameService', function() {

      beforeEach(module('ng-boilerplate'));

      var NameService;
      beforeEach(inject(function (_NameService_) {
        NameService = _NameService_;
      }));

      describe('#formatName()', function() {
        it('should title case a given string', function() {
          expect(NameService.formatName('IAN')).to.equal('Ian');
          expect(NameService.formatName('bill murray')).to.equal('Bill Murray');
        });
      });

    });
  }
);
